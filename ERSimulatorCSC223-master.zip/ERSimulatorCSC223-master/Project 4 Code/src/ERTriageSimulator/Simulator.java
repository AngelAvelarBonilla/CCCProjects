package ERTriageSimulator;
import java.io.*;
import java.util.Scanner;

public class Simulator {
    static File nameFile = new File("Project 4 Code/names.txt");
    static Scanner file;
    static String[] name = new String[189];
    static int nameCount = 0;

    public Simulator(){
    }

    //PRE: User has set the constants to their desired values and passed them thru
    //POST: the simulation is run with the desired values and the results are outputted

    /**
     *
     * @param interval interval at which time moves forward
     * @param chance chance of a patient arriving
     * @param room number of rooms available
     * @param totalTime time that the simulation will run for
     * @throws FileNotFoundException
     */
    public static void runSimulation(int interval, int chance, int room, int totalTime) {//simulation with custom values passed in
        final int ARRIVAL_INTERVAL = interval;
        final double CHANCE_OF_ARRIVAL = chance;
        final int NUM_OF_ROOMS = room;
        final double SIMULATION_TIME = totalTime * 60;//converts hours into minutes

        ERManager manager = new ERManager(ARRIVAL_INTERVAL, NUM_OF_ROOMS);
        loadNames();
        while (manager.getClock() < SIMULATION_TIME){
            System.out.println("________________________________________________________");
            System.out.println("Clock: " + manager.getClock() + " minutes");//current time
            manager.processPatient();
            //provides a chance for a patient to arrive
            if (getRandomNumber() <= CHANCE_OF_ARRIVAL) {
                String name = getName();
                int severity = generateSeverity();
                int timeNeeded = generateTimeNeeded(severity);
                manager.add(new Patient(name, severity, timeNeeded));
            }
            //process patients

            manager.incrementClock();

            }
        manager.printFinalResults();

        }



        //PRE: the simulation is being run and patient is being created, and loadNames() has been called
    //POST: a name has been grabbed from the array of names loaded earlier

    /**
     *
     * @returns a name from the name array at position nameCount is returned
     */
    private static String getName(){
        String result = name[nameCount];
        nameCount++;
        if (nameCount == 189)
            nameCount = 0;//resets counter once all of the names have been used up, issues found during test cases
        return result;
    }
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    //Generates a random number between 1 and 100
    //Used for the randomization, out of 100 so that 1-100% probability can be used

    /**
     *
     * @return returns a random number between 1 and 100
     */
    private static int getRandomNumber(){
        return (int)(Math.random() * (100))+1;
    }
    //Generates a random number between 1 and 8 as that's how many 5 min intervals there are between 10 and 45

    /**
     *
     * @returns a number between 1 and 8 user for the severity level
     */
    private static int generateSeverity(){
        return (int)(Math.random() * 8 + 1);
    }

    //Preforms the necessary operations to scale the time needed due to the severity

    /**
     *
     * @param severity the severity level is passed thru
     * @returns the time needed based on the severity level
     */
    private static int generateTimeNeeded(int severity){
        return severity * 5 + 5;//this gets us the time needed based on the severity
    }

    //PRE: the simulation has begun to run
    //POST: Names have been read from names.txt and into an array of strings
//loads names from the file into an array

    /**
     *
     * @throws FileNotFoundException
     * loads the names in the file into an array
     */
    private static void loadNames() {
        try {
            file = new Scanner(nameFile);
            for (int i = 0; i < 189; i++)
                name[i] = file.nextLine();
        }
        catch (FileNotFoundException err){//if the file cannot be found, patients will be numbered instead of named
            for (int i = 0; i < 189; i++){
                name[i] = "Patient #" + (i + 1);
            }
        }
    }
}


