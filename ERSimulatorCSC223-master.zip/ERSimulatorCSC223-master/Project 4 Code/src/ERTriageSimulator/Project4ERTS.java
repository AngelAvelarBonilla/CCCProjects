package ERTriageSimulator;
import ERTriageSimulator.Simulator;

import java.io.FileNotFoundException;

public class Project4ERTS {
    public static void main(String[] args){
        //modifiers, the values below can be edited to adjust simulation
        int arrivalInterval = 5;//number that time increments in (minutes) DEFAULT: 5
        int chanceOfArrival = 25;//percentage chance that a patient arrives DEFAULT: 25
        int numOfRooms = 4;//number of total rooms available DEFAULT = 4
        int totalTime = 6;//number of hours er is simulated DEFAULT = 6

        Simulator.runSimulation(arrivalInterval, chanceOfArrival, numOfRooms, totalTime);
    }
}
