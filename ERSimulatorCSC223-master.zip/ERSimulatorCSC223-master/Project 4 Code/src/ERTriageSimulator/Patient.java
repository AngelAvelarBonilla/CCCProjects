package ERTriageSimulator;

public class Patient implements Comparable<Object> {
    private int timeIn;//time at which patient arrived
    private int timeNeeded;//time needed to assist the patient
    private int severity;//severity of the patients condition
    private int timeSpent;//how much time spent treating the patient
    private String name;//patients name

    //PRE: a severity has been generated and the time needed has been calculated
    //POST: A patient is created using the name from the array and the values passed thru

    /**
     *
     * @param name of the patient is passed thru
     * @param severity level of the patient is passed
     * @param timeNeeded (in minutes) in order to treat the patient is passed thru
     */
    public Patient(String name, int severity, int timeNeeded){
        this.name = name;
        this.severity = severity;
        this.timeNeeded = timeNeeded;
    }

    public Patient(){}//default empty patient

    //the time the patient has spent towards being healed is incremented

    /**
     *
     * @param timeInterval passes in the time at which patients arrive which is also the interval at
     *                     which time advances
     */
    public void moveForward(int timeInterval){
        timeSpent += timeInterval;
    }

    //checks to see if the patient has been treated

    /**
     *
     * @return returns whether the time the patient has spent in the room satisfies the time
     * that is needed to treat the patient
     */
    public boolean checkForTreated(){
        if (timeSpent >= timeNeeded)
            return true;
        else
            return false;
    }

//STANDARD SETTERS AND GETTERS

    public void setSeverity(int severity){this.severity = severity;}
    public int getSeverity(){return severity;}

    public void setName(String name){this.name = name;}
    public String getName(){return name;}

    public void setTimeNeeded(int adjustedTimeNeeded){timeNeeded = adjustedTimeNeeded;}
    public int getTimeNeeded(){return timeNeeded;}

    public void setTimeIn(int currentTime){timeIn = currentTime;}
    public int getTimeIn(){return timeIn;}

    public void setTimeSpent(int time){timeSpent = time;};
    public int getTimeSpent(){return timeSpent;};

    //Compares patients based on their severity(higher severity more prioritized)
    //if the severities are the same, their arrival time is taken into account

    /**
     *
     * @param rSide right side of the equation (x </> y) (y in that case)
     * @returns positive number if rside is > than left side
     * negative if leftside is > rside
     * if the severity is equal than the time they arrived is used for comparison
     */
    public int compareTo(Object rSide){
        int result = ((Patient)rSide).getSeverity() - this.severity;
        if (result==0)
            result = (((Patient)rSide).getTimeIn()) - this.getTimeIn();
        return result;
    }

    /**
     *
     * @outputs the patient name, the time arrived and the time that was needed to assist
     */
    public String toString(){
        String result = "";
        result += ("Patient: " + name + "\t|Time Arrived: " + timeIn + " minutes\t\t|Time needed to assist: " + timeNeeded + " minutes\n");
        return result;
    }
}
