package ERTriageSimulator;

public class Room {
    private Patient patient;//stores the patient that is in this room
    private boolean isEmpty;//keeps track of whether the room is empty or not
    Room(){
        isEmpty = true;
    }

    //PRE: A patient is at the head of the priority queue
    //POST: The patient has been removed from the priority queue and placed into the room

    /**
     *
     * @param p the patient is added to the room
     */
    public void enterPatient(Patient p){
        patient = p;
        isEmpty = false;
    }
    //PRE: The patient has spent sufficient time in the room
    //POST: the patient is removed and the room is marked as empty(Ready for another patient)

    /**
     * sets the patient to null and sets the room to open
     */
    public void removePatient(){
        patient = null;
        isEmpty = true;
    }

    //returns the patient(standard getter)

    /**
     *
     * @return the patient object stored in this room
     */
    public Patient getPatient(){
        return patient;
    }

    //checks to see if the room as available for a patient

    /**
     *
     * @returns whether the room is empty or not
     */
    public boolean isEmpty(){return isEmpty;};

}
