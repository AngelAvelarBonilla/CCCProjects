package ERTriageSimulator;

import java.util.PriorityQueue;

/*================================
* ERManager.java
* Angel Avelar-Bonilla
* Processes the patients and
* keeps track of their time spent in
* the ER
*================================== */
public class ERManager {

    private PriorityQueue<Patient> patientQueue = new PriorityQueue<>();
    private int clock;
    private int numOfRooms;
    private int arrivalInterval;
    private Patient currentPatient;
    private Room[] room;

    //variables used to calculate overall stats for the  ER sim
    int longestWaitTime = 0;
    double totalTimeWaited = 0;
    double totalPatientsAssisted = 0;


    /**
     *
     * @param arrivalInterval interval at which patients arrive and time advances
     * @param numOfRooms number of rooms available for patients
     */
    public ERManager(int arrivalInterval, int numOfRooms) {
        clock = 0;
        this.arrivalInterval = arrivalInterval;
        room = new Room[numOfRooms];
        for (int i = 0; i < numOfRooms; i++){
            room[i] = new Room();
        }
        this.numOfRooms = numOfRooms;
    }
    //PRE: the simulation is being run and the chance of arrival percentage has determined a patient should arrive
    //POST: A patient is added to the priority Queue

    /**
     *
     * @param patient gets added to the queue and is outputted
     */
    public void add(Patient patient){
        patient.setTimeIn(clock);//sets the patients timeIn as the current time
        patientQueue.add(patient);//adds patient to the priority queue
        System.out.println(patient.getName() + " has arrived at " + clock + " minutes with a severity level of " + patient.getSeverity());
        System.out.println("Treatment Time: " + patient.getTimeNeeded() + " minutes");
    }

    //PRE: the simulation has begun
    //POST: Rooms have been assigned appropriately, patients are checked to see if they have been treated successfully

    /**
     *
     * @throws RuntimeException
     * fills appropriate empty rooms, moves time forward, removes patients from rooms if they have been treated
     */
    public void processPatient() throws RuntimeException {
            fillRooms();
            for (int i = 0; i < numOfRooms; i++){
                if(room[i].getPatient() != null) {
                    currentPatient = room[i].getPatient();
                    currentPatient.moveForward(arrivalInterval);
                }

                if(room[i].getPatient() != null && currentPatient.checkForTreated()){
                    int timeSpent = clock-currentPatient.getTimeIn();
                    System.out.println(currentPatient + "Total Time Spent in the ER: " + timeSpent + " minutes");
                    if (timeSpent > longestWaitTime)
                        longestWaitTime = timeSpent;
                    totalTimeWaited += timeSpent;
                    totalPatientsAssisted++;
                    room[i].removePatient();
                    }
            }


    }

    //PRE: The simulation has begun, the numOfRooms constant has determined the number of rooms
    //POST: Rooms are filled depending on the available patients
    //fills as many rooms as possible
    public void fillRooms(){
        for (int i = 0; i < numOfRooms; i++){
            if (room[i].isEmpty() && patientQueue.peek() != null){
                room[i].enterPatient(patientQueue.poll());
            }
        }

    }

    //returns time
    public int getClock(){
        return clock;
    }

    //pushes clock forward based on the arrivalInterval constant set by the user
    public void incrementClock(){
        clock += arrivalInterval;
    }

    //uses the variables racking the stats and outputs appropriately
    public void printFinalResults(){
        System.out.println("Longest Time Spent in the ER: " + longestWaitTime + " minutes");
        System.out.println("Average Wait Time: " + (totalTimeWaited / totalPatientsAssisted) + " minutes");
    }
    public String toString(){
        String s = "" + patientQueue;
        return s;
    }
}
