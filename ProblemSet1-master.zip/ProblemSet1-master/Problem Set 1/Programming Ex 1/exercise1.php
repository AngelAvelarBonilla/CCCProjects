/*
Author: Angel Avelar-Bonilla
Date: 3/20/2020
Programming Exercise 1 in PHP
 */
 <?php

 $k = ($j + 13) / 27;
 while($k <= 10){
     $k++;
     $i = 3 * $k - 1;
 }


 exit();