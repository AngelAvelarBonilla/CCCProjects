/*
Author: Angel Avelar-Bonilla
Date: 3/20/2020
Programming Exercise 1 in Java
 */
public class exercise1{
    public static void main(String[] args){
        int j = 0;
        int i = 0;

        int k = (j + 13) / 27;
        while(k <= 10){
            k++;
            i = 3 * k - 1;
        }


    }
}