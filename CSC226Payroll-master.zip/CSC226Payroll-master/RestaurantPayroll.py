'''
CSC-226 Chapter 12/weeks 11-12 Topics OOP - Inheritance
Sample Program:  RestaurantPayroll
Sample Language: Python
Programmer: Angel Avelar-Bonilla
Date:       4/24/2020
Description: RestaurantPayroll.py
Inheritance/Polymorphism Programming Project
'''

from RestaurantWorker import HourlyWorker
from RestaurantWorker import WaitStaff
from RestaurantWorker import KitchenStaff


class RestaurantPayroll:
    def main(self):
        restaurantWorkers = {
            HourlyWorker("Tom Nook", "123-456-7890", 'B', 40),
            HourlyWorker("Isabelle", "543-545-1244", 'L', 35),
            WaitStaff("Timmy Nook", "341-433-2562", 'B', 30, 40, 60),
            WaitStaff("Tommy Nook", "141-453-2564", 'D', 40, 70, 60),
            KitchenStaff("K.K. Slider", "413-531-5324", 'B', 45),
            KitchenStaff("Blathers", "413-531-5324", 'B', 60)
        }
        for worker in restaurantWorkers:
            worker.generatePayCheck()


payroll = RestaurantPayroll
payroll.main(payroll)

