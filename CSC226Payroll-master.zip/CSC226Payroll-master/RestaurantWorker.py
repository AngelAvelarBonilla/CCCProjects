'''
CSC-226 Chapter 12/weeks 11-12 Topics OOP - Inheritance
Sample Program:  RestaurantPayroll
Sample Language: Python
Programmer: A. Wright
Date:       4/19/2020
Description: RestaurantWorker.py
Inheritance/Polymorphism Programming Project
 *
 * super class RestaurantWorker has a self.__name, phone, netPay and a shift  these
 * are common properties of all workers at the Blue Moon Cafe
 * set and get methods are provided and there is a
 * polymorphic generatePayCheck() method that is meant to be overridden in
 * sub classes
 * NOTE the enum type is not supported by Python 3 so Shift is represented as a Set

 MODIFIED BY: Angel Avelar-Bonilla
 DATE: 4/23/2020
 *
'''


class RestaurantWorker:
    allShifts = {'B', 'L', 'D', 'S'}
    healthInsuranceCOST = 68.50
    '''
    * INITIALIZER (like a CONVERSION constructor that builds a RestaurantWorker object)
    * accepts inputs for: self.__name, phone, shift  
    *
    '''

    def __init__(self, name, phone, shift):

        self.__name = name  # __name is 'hidden' (by name mangling) no direct
        self.__phone = phone  # access from outside class, app uses
        self._shift = shift  # @property getter and @setter
        self._netPay = 0

    # Python style of set/get methods are like C# fields - uses properties

    @property  # can take the place of a getName() *READ-ONLY* attribute
    def name(self):  # Coded in C# style of protecting object 'fields'
        ''' Return the name.'''
        return self.__name

    @name.setter  # can take the place of a setName()
    def name(self, name):
        ''' Set the name '''
        self.__name = name

    '''
     * Mutator: setPhone()        coded like Java
     * Sets self.__phone to the provided input phone number
     *  
     '''

    def setPhone(self, phone):
        self.__phone = phone

    '''
     * Mutator: setShift()
     *          verify valid input (member of set allShifts
     '''

    def setShift(self, shift):
        if shift in RestaurantWorker.allShifts:
            self._shift = shift

    '''
     * Accessor: getPhone()
     *     returns a copy of the object's phone number
     '''

    def getPhone(self):
        return self.__phone

    '''
     * Accessor: getShift()
     *     returns a copy of the object's shift Breakfast, Lunch, Dinner, or Swing
     '''

    def getShift(self):
        if self._shift == 'B':
            shift = 'Breakfast'
        elif self._shift == 'L':
            shift = 'Lunch'
        elif self._shift == 'D':
            shift = 'Dinner'
        else:
            shift = 'Swing'
        return shift

    '''
     * Accessor: getPay()
     *     returns a copy of the object's pay
     '''

    def getPay(self):
        return self._netPay

    '''
    * Accessor: getHealthInsuranceCost()
    *   returns the health insurance cost
    '''

    def getHealthInsuranceCOST(self):
        return self.healthInsuranceCOST

    '''
    * Mutator: generatePayCheck()
    * specific to each RestaurantWorker
    * 
    '''

    def generatePayCheck(self):

        print(" ******************NON-NEGOTIABLE***********")
        print('\tName: ' + self.__name)
        print(" ---------------DO NOT CASH----------------")
        print(f'\n\t ****$ {self._netPay:.2f}')
        print('\n*******************************************')

    '''
     * Accessor: __str__() -- Python's toString()
     * 
     * produces a String version of the object
    '''

    def __str__(self):
        out = "\tBlue Moon Cafe Employee Information\n"
        out += " " + self.__name + "\t" + self.__phone + "\tShift: " + self.getShift() + "\n"

        return out


class HourlyWorker(RestaurantWorker):
    hourlyRate = 15

    def __init__(self, name, phone, shift, hours):
        super().__init__(name, phone, shift)

        self._hours = hours

    @property  # can take the place of a gethours()
    def hours(self):  # can be called by using its identifier
        ''' returns the number of hours worked '''
        return (self._hours)

    @hours.setter  # can take the place of a setHours()
    def hours(self, hours):
        ''' Set the hours '''
        self._hours = hours

    def calculatePay(self):
        self._netPay = self._hours * HourlyWorker.hourlyRate - self.getHealthInsuranceCOST()
        return self._netPay

    def generatePayCheck(self):
        self.calculatePay()
        super().generatePayCheck()

    def __str__(self):
        out = super().__str__()
        out += 'HourlyWorker Pay Rate:$ {:,.2f}'.format(self.hourlyRate)
        return out


class WaitStaff(HourlyWorker):
    gratuities = 0
    uniformAllowance = 0

    def __init__(self, name, phone, shift, hours, gratuities, uniformAllowance):
        super().__init__(name, phone, shift, hours)

        self.gratuities = gratuities
        self.uniformAllowance = uniformAllowance

    '''
    * Mutator: setGratuities()
    *     sets gratuities to the amount passed in
    '''

    def setGratuities(self, gratuities):
        ''' Set gratuities'''
        self.gratuities = gratuities

    '''
    * Accessor: getGratuities()
    *     returns a copy of the object's gratuities
    '''

    def getGratuities(self):
        ''' Return gratuities'''
        return self.gratuities

    '''
    * Accessor: getUniformAllowance()
    *    returns a copy of the objects uniformAllowance
    '''

    def getUniformAllowance(self):
        ''' Return Uniform Allowance'''
        return self.uniformAllowance

    def calculatePay(self):
        self._netPay = self._hours * self.hourlyRate + self.gratuities - self.healthInsuranceCOST
        return self._netPay

    def generatePayCheck(self):
        self.calculatePay()
        super().generatePayCheck()
        print(f'\nGratuities: ****$ {self.gratuities:.2f}')
        print(f'\nUniform Allowance: ****$ {self.uniformAllowance:.2f}')
        print('\n*******************************************')

    def __str__(self):
        out = super().__str__()
        out += 'Wait Staff Gratuities: $ {:,.2f}'.format(self.gratuities)
        out += 'Wait Staff Uniform Allowance: $ {:,.2f}'.format(self.uniformAllowance)
        return out


class KitchenStaff(HourlyWorker):
    overTimeRate = 15

    def __init__(self, name, phone, shift, hours):
        super().__init__(name, phone, shift, hours)

        self.overTimeRate = self.hourlyRate * 1.5

    '''
    * Mutator: setOverTimeRate()
    *   sets overTimeRate to the amount passed in
    '''

    def setOverTimeRate(self, overTimeRate):
        ''' Set overTimeRate '''
        self.overTimeRate = overTimeRate

    '''
    * Accessor: getOverTimeRate()
    *   returns a copy of the objects overTimeRate
    '''

    def getOverTimeRate(self):
        ''' Return overTimeRate '''
        return self.overTimeRate

    def calculatePay(self):
        # Pay  calculation for workers with 40 or less hours (No overtime)
        if self.hours <= 40:
            self._netPay = self._hours * self.hourlyRate - self.healthInsuranceCOST
        # Pay calculation for workers with more than 40 hours (overtime)
        else:
            self._netPay = 40 * self.hourlyRate + (self._hours - 40) * self.overTimeRate - self.healthInsuranceCOST
        return self._netPay

    def generatePayCheck(self):
        self.calculatePay()
        super().generatePayCheck()
        if self._hours > 40:
            print(f'\nOvertime Rate: ****$ {self.overTimeRate:.2f}')
            print(f'\nOvertime Hours Worked: **** {self._hours - 40}')
            print('\n*******************************************')

    def __str__(self):
        out = super.__str__()
        out += 'Kitchen Staff Overtime Rate: $ {:,.2f}'.format(self.overTimeRate)
        return out
