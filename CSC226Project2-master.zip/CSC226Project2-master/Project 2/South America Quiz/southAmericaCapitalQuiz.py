# CSC-226 Programming Languages
# Programmer: Angel Avelar-Bonilla
# Date: 2/11/2020
# Project 2: South America Quiz

#TODO Pre and Post Operators

def main():
    beginQuiz()

#PRE: The User is is ready to begin the quiz
#POST: Asnwers are filled out, the user is shown his score, the answer key
#  and his percentage correct
def beginQuiz():
    print ("Quiz Time!\nEnter the capital to each South American Country that appears:")
    answerKey = loadInCountriesAndCapitals("South America Quiz\SACapitals&Countries.txt")
    score = 0

    for k, v in answerKey.items():
        if input("\nCountry: " + k + "\nCapital: ") == v:
            print("Correct!")
            score += 1
            print("Current Score: %i"%score)
        else:
            print("\nIncorrect >:(")
            print("Current Score: %i"%score)
            print("Correct Answer: " + v)

    print("\nAnswer Key:")
    for k, v in answerKey.items():
        print("Country: " + k, end="  |  ", flush=True)
        print("Capital: " + v, end="\n\n", flush=True)

    print("\nYour Score: %i"%score)
    percentGrade = round((score/len(answerKey))*100, 2)
    print("Percentage Correct: " + str(percentGrade) + "%")


#PRE: A quiz has begun, a filename is passed thru
#POST: The file is checked to see if it exists, its contents have been
# put in a hasmap in which the key is the country and the value is the capital
def loadInCountriesAndCapitals(filename: str) -> dict:
    try:
        f = open(filename, "r")
    except FileNotFoundError:
        print ("Error- The file: %s does not exist or could not be found" %filename)
    
    contentsOfFile = f.read()
    contentsOfFile = contentsOfFile.replace("\n",":")
    contentsOfFile = contentsOfFile.split(':')
    f.close()

    countries = list(map(str.strip, contentsOfFile[::2]))
    capitals = list(map(str.strip, contentsOfFile[1::2]))
    answerKey = {}
    for i in range(len(countries)):
        answerKey[countries[i]] = capitals[i]

    return answerKey


main()