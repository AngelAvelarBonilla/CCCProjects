# CSC-226 Programming Languages
# Programmer: Angel Avelar-Bonilla
# Date: 2/11/2020
# Project 2: Password Authenticator

def main():
    passwordInitial()
    
'''
Initializes the process, Prompts the user to enter a password
Calls the correct functions depending on the results of
the verify function
Pre: The program has been run, or the password did not meet the requirements
Post: The password is set and has been confirmed
'''
def passwordInitial():
    password = input("Please enter a password that meets the following criteria:\n   -Minimum of 9 characters\n   -1 Upper case letter, 1 Lower case letter\n   -Atleast 1 number\n>")
    if(verify(password)):
        print ("Your password met the requirements")
        passwordConfirm(password)
    else:
        print ("Your password did not meet the requirements.\n")
        passwordInitial()

'''
Prompts the user to retype their password for confirmation
Calls itself until the password is successfully retyped
Pre: The password has met the criteria
Post: The password is confirmed 
'''
def passwordConfirm(password):
    passwordRetyped = input("Please retype your password\n>")
    if(password != passwordRetyped):
        print("The password entered does not match\n")
        passwordInitial()
    else:
        print ("Your passwords match! You have created your new password.")

    return True

'''
Takes in a password: string and checks to see if it meets the requirements
Pre: A password is entered
Post: The password is checked for whether it is valid or not
'''
def verify(password):
    
    if (len(password) >= 9):
        meetsCharReq = True
    else:
        meetsCharReq = False

    meetsLowerCaseReq = False
    meetsUpperCaseReq = False
    meetsNumReq = False
    for letter in password:
        if (letter.isupper()):
            meetsUpperCaseReq = True
        elif(letter.islower()):
            meetsLowerCaseReq = True
        elif(letter.isnumeric()):
            meetsNumReq = True
    
    if(meetsCharReq and meetsLowerCaseReq and meetsUpperCaseReq and meetsNumReq):
        isValidPass = True
    else:
        isValidPass = False
    
    return (isValidPass)
    
main()
