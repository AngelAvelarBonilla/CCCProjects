package actionListeners;

import java.awt.event.*;
import java.io.*;
import java.util.*;
import GUI.mainGUI;

public class textToSetEvent implements ActionListener {

    private Scanner scan;
    private String fileName;
    private Set<String> setOfUniqueWords;
    private static File currentFile;

    public void actionPerformed(ActionEvent e){
        fileName = mainGUI.getFileName().getText();
        File file = new File(fileName);
        if (!file.exists())
            file = new File(fileName + ".txt");//if the file opened previously does not exist,
                                                         //.txt will be appended and we will try to find it again

        try {
                scan = new Scanner(file);
        } catch (FileNotFoundException e1) {
            mainGUI.getOutputArea()
                    .append("The file you specified could not be found\n");
        }

        setOfUniqueWords = new TreeSet();
        while (scan.hasNext()) {
            setOfUniqueWords.add(scan.nextLine());
        }

        for (String uniqueWord : setOfUniqueWords) {
            mainGUI.getOutputArea().append(uniqueWord + "\n");
        }

        currentFile = file;//last file opened is stored so that the wordCountEvent searches the last file displayed

    }

    public static File getCurrentFile(){
        return currentFile;
    }

}