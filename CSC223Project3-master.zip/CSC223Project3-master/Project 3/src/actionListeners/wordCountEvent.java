package actionListeners;

import GUI.mainGUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class wordCountEvent implements ActionListener {

    private Scanner scan;
    private int timesOccured;
    private String wordToSearch;
    private File file;

    public void actionPerformed(ActionEvent e) {
        timesOccured = 0;//resets to 0 every time a new search begins
        wordToSearch = mainGUI.getWordToSearch().getText();
        file = textToSetEvent.getCurrentFile();

        try {
            scan = new Scanner(file);
        } catch (FileNotFoundException e1) {
            mainGUI.getOutputArea().append("A valid file has not been opened\n");
        }

        while (scan.hasNext()){
            if (scan.nextLine().equals(wordToSearch))
                timesOccured++;
        }
        if (file.exists())
        mainGUI.getOutputArea().append("\"" + wordToSearch + "\" appears " + timesOccured + " time(s) in the file: \""
        + file.getName() + "\"\n");


    }


}