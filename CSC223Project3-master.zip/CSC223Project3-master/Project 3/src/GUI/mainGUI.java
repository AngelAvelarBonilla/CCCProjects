package GUI;

import javax.swing.*;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.event.*;
import actionListeners.*;

public class mainGUI {

    static private JTextField fileName;
    static private JTextField wordToSearch;
    static private JTextArea outputField;
    public static void main(String args[]) {
        createAndShowGUI();
    }

    private static void createAndShowGUI() {
        // create and setup the window
        JFrame frame = new JFrame("UniqueWordsFinder!");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // setup the content frame
        addComponentsToFrame(frame);
        // display the window
        frame.pack();
        frame.setVisible(true);
        frame.setResizable(false);
    }

    private static void addComponentsToFrame(JFrame frame) {
        frame.setSize(300, 300);

        frame.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.weightx = 1.0;
        c.weighty = 1.0;

        JButton textSearchButton = new JButton("Find");//Find for searching the list
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 2;
        c.gridy = 2;
        c.anchor = GridBagConstraints.PAGE_START;
        frame.add(textSearchButton, c);
        ActionListener textToSetEvent = new textToSetEvent();
        textSearchButton.addActionListener(textToSetEvent);

        JButton wordSearchButton = new JButton("Find");//find for searching for occurrences of a word
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 2;
        c.gridy = 3;
        c.anchor = GridBagConstraints.PAGE_START;
        frame.add(wordSearchButton, c);
        ActionListener wordCountEvent = new wordCountEvent();
        wordSearchButton.addActionListener(wordCountEvent);


        JLabel fileFieldLabel = new JLabel("Enter filename here:");// labels the filename field
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 1;
        c.gridy = 1;
        frame.add(fileFieldLabel, c);

        JLabel wordCounterLabel = new JLabel("Word Counter:");// labels the field for the word counter
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 1;
        c.gridy = 2;
        c.anchor = GridBagConstraints.PAGE_END;
        frame.add(wordCounterLabel, c);

        JLabel wordSetLabel = new JLabel("Unique Words:");//labels the output
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 4;
        c.gridy = 1;
        frame.add(wordSetLabel, c);

        JTextField fileNameTextField = new JTextField("");// input field for filename
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 1;
        c.gridy = 2;
        c.anchor = GridBagConstraints.PAGE_START;
        frame.add(fileNameTextField, c);
        fileName = fileNameTextField;

        JTextField wordSearchTextField = new JTextField("");//input field desired word
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 1;
        c.gridy = 3;
        c.anchor = GridBagConstraints.PAGE_START;
        frame.add(wordSearchTextField, c);
        wordToSearch = wordSearchTextField;


        JTextArea outputArea  = new JTextArea(20, 30);//Main output area for
        c.fill = GridBagConstraints.NORTH;
        c.gridx = 4;
        c.gridy = 2;
        c.gridheight = GridBagConstraints.REMAINDER;
        c.anchor = GridBagConstraints.CENTER;
        outputArea.setEditable(false);
        outputArea.setLineWrap(true);
        JScrollPane scroll = new JScrollPane(outputArea);
        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        frame.add(scroll, c);
        outputField = outputArea;


        c.fill = GridBagConstraints.BOTH;//creates gap between input and output space
        c.gridx = 3;
        c.gridy = 1;
        c.gridheight = 1;
        c.gridwidth = 1;
        frame.add(Box.createHorizontalStrut(50), c);
    }

    public static JTextField getFileName(){
        return fileName;
    }

    public static JTextField getWordToSearch(){
        return wordToSearch;
    }

    public static JTextArea getOutputArea(){
        return outputField;
    }

}