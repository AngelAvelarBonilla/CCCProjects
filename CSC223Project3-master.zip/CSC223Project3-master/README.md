# CSC223Project3
Project 3 for CSC223: Data Structures and Algorithms

Reads the contents of a text file and builds a set of all the
unique words in the file. Provides the list of words in alphabetical order. 
Allows the user to enter a word from the list and reports how many
times the word was used in the file.
