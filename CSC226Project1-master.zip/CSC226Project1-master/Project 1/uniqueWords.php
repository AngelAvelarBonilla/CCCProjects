//Author: Angel Avelar-Bonilla
//A php program that reads in up to 50 words, stores them in an array
//and drops the duplicates, then lists the contents of the array

<?php
//reads a string from the user; A string is passed as a parameter to prompt the user
$response = readline("Are you importing the words via file or typing them yourself?(F/T) ");

readline_add_history($response);//the line must be added manually to the command line history
$response = strtoupper($response);//Normalizes the response by making it upper case
$uniqueWords = array();//creates an array that will be used to store the unique words

//strcmp() takes two strings and returns 0 if they are equal, < 0 if str 1 is less than str, etc.\
//however strings can aslo be evaluated for equivalence using ==
if (strcmp($response, "T") == 0)
{
    //echo == print, echo has no return value while print returns 1
    echo "Please enter each word one by one and type 'STOP' to end your input\n";

    $inputCount = 0;//will be used to track the amount of inputs
    $index = 0;//Keeps track of the index of the array

    //loops while 'STOP' is not inputted and there are not 50 words inputted, && == and
    while (($response != "STOP") and ($inputCount < 50)){
        $response = readline();//reads in input from keyboard and stores response

        //in_array checks for membership within an array, Case Sensitive
        if(in_array($response, $uniqueWords) == false and $response != "STOP"){
        $uniqueWords[$index++] = $response;//stores the response at the correct index within the array, post increment after storage
        }
        $inputCount++;
    }
}elseif ($response == "F")
{
    $filename = readline("Enter the name of your file: ");
    $file = fopen($filename, "r");
    //fopen() is used to open the file and needs the filename and the mode type which in our case is 'r' for
    //read only
    if ($file == false) {echo "Error opening file"; exit();}//Exits if file could not be found/opened

    //
    while(! feof($file) and ($inputCount < 50)){
        $wordIn = fgets($file);//fgets() is used to read a single line from a file

        //in_array checks for membership within an array, Case Sensitive
        if(in_array($wordIn, $uniqueWords) == false){
        $uniqueWords[$index++] = $wordIn;//stores the response at the correct index within the array, post increment after storage
        }
        $inputCount++;
    }
    fclose($file);//closes the file

    
}else
{
echo "Your input was invalid :(";
exit();
}
//prints the contents of the array
print_r($uniqueWords);
exit();